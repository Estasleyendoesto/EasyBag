LOCALIZATION.esES = {
	{text = "Todo"},
	{text = "Reciente"},
	{text = "Llaves",                                        typo = "Miscelánea", subtype= "Llave"},
	{text = "Cofres",                                        typo = "Miscelánea", subtype= "Otros"},
	{text = "Objetos de Misión",                             typo = "Miscelánea", subtype= "Misión"},
	{text = "Coleccionables (Monturas, Mascotas, Juguetes)", typo = "Miscelánea"},
	{text = "Materiales de Profesión",                       typo = "Habilidad comercial"},
	{text = "Armaduras",                                     typo = "Armadura"},
	{text = "Armas",                                         typo = "Arma"},
	{text = "Anillos y amuletos",                            typo = "Armadura"},
	{text = "Abalorios",                                     typo = "Armadura"},
	{text = "Consumibles",                                   typo = "Consumible"},
	{text = "Recetas",                                       typo = "Receta"},
	["filter"] = "Filtrar",
	["reset"] = "Limpiar Filtro"
}