LOCALIZATION.enUS = {
	{text = "All"},
	{text = "Recent"},
	{text = "Keys",                              type = "Miscellaneous", subtype= "Key"},
	{text = "Chests",                            type = "Miscellaneous", subtype= "Other"},
	{text = "Quest Items",                       type = "Miscellaneous", subtype= "Quest"},
	{text = "Collectibles (Mounts, Pets, Toys)", type = "Miscellaneous", subtype= "Other"},
	{text = "Materials (Profession)",            type = "Trade Goods"},
	{text = "Armors",                            type = "Armor"},
	{text = "Weapons",                           type = "Weapon"},
	{text = "Rings and Amulets",                 type = "Miscellaneous", subtype= "Jewelry"},
	{text = "Trinkets",                          type = "Miscellaneous", subtype= "Trinket"},
	{text = "Consumables (Potions, Food, ...)",  type = "Consumable"},
	{text = "Recipes",                           type = "Recipe"},
	["tooltip"] = "Filter By"
}